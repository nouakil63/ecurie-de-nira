=== Nira Booking ===
Contributors:      noksconsulting
Author:            NOK'S Consulting
Tags:              booking, reservation, airbnb, stripe, gite, equestre
Requires at least: 6.0
Tested up to:      6.6
Requires PHP:      7.4
Stable tag:        2.1.5
License:           GPLv2 or later

Système de réservation complet pour les gîtes des Écuries de Nira, avec
calendrier façon Airbnb, paiement Stripe, synchronisation iCal bidirectionnelle
et tout paramétrable depuis l'admin WordPress.

== Description ==

Plugin WordPress dédié aux Écuries de Nira : gestion d'hébergements, tarifs
saisonniers et hebdomadaires, disponibilités (blocage manuel + sync Airbnb
iCal), prise de réservation en direct avec paiement Stripe (acompte ou
intégral), emails transactionnels et tableau de bord administrateur.

**Fonctionnalités**

* Widget de réservation façon Airbnb (shortcode `[nira_booking slug="..."]`)
  avec plage de dates sur calendrier 2 mois, stepper voyageurs, détail de
  prix en direct (base + ménage + taxes + acompte).
* Gestion des hébergements : capacité, chambres, salles de bain, heures
  d'arrivée/départ, séjour min/max, prix de base, frais de ménage, acompte %,
  politique d'annulation, équipements, URL Airbnb.
* Règles tarifaires : saisons (plage de dates) et jours de semaine, avec
  système de priorité pour les conflits.
* Synchronisation iCal bidirectionnelle : import des blocages Airbnb (plusieurs
  flux par hébergement), export de vos réservations directes vers Airbnb.
* Paiement Stripe (Payment Intents + webhooks) — acompte uniquement ou
  paiement intégral.
* "Holds" de réservation avec expiration automatique si non payé.
* Emails : confirmation client, notification admin, annulation.
* Réglages globaux : devise, TVA, taxe de séjour, identité, délais, politiques.

== Installation ==

1. Copier le dossier `nira-booking/` dans `wp-content/plugins/`.
2. Activer depuis *Extensions* de WordPress. Les tables et les réglages par
   défaut sont créés automatiquement.
3. Ouvrir le menu **Nira Booking** pour configurer :
   * **Réglages** → devise, Stripe (pk/sk/webhook secret), horaires, emails.
   * **Hébergements** → prix, capacité, équipements, photos.
   * **Tarifs** → règles saisonnières (été, Noël…) ou par jour.
   * **Synchronisation** → URL iCal depuis Airbnb (Calendrier → Paramètres →
     Exporter) pour chaque hébergement, puis URL d'export Nira à coller dans
     Airbnb pour bloquer automatiquement les dates.
4. Configurer le webhook Stripe :
   `https://votresite.fr/wp-json/nira/v1/stripe-webhook`
   Événements : `payment_intent.succeeded` et `payment_intent.payment_failed`.
5. Sur n'importe quelle page : `[nira_booking slug="appartement"]` ou
   `[nira_booking slug="duplex"]`.

== Intégration dans la page Airbnb existante ==

Le fichier `pge airbnb.html` contient déjà deux appels shortcode, un par
hébergement, à la place des anciennes cartes de réservation. Une fois la page
convertie en page/template WordPress, les widgets s'afficheront
automatiquement à l'endroit du shortcode.

== Arborescence ==

```
nira-booking/
├── nira-booking.php                 — bootstrap plugin
├── includes/
│   ├── class-nira-db.php            — migrations + cron
│   ├── class-nira-settings.php      — réglages globaux
│   ├── class-nira-properties.php    — CRUD hébergements
│   ├── class-nira-pricing.php       — règles tarifaires + quote
│   ├── class-nira-booking.php       — cycle de vie réservation
│   ├── class-nira-availability.php  — calendrier + vérifs
│   ├── class-nira-stripe.php        — Payment Intents + webhook
│   ├── class-nira-ical.php          — import/export iCal
│   ├── class-nira-email.php         — mails transactionnels
│   ├── class-nira-ajax.php          — endpoints publics
│   ├── class-nira-rest.php          — endpoints REST (calendar/bookings)
│   ├── class-nira-shortcode.php     — rendu widget
│   └── class-nira-admin.php         — écrans WP-Admin
├── templates/admin/*.php            — vues admin server-rendered
├── assets/css/{frontend,admin}.css
└── assets/js/{frontend,admin}.js
```

== Tâches planifiées (cron) ==

* `nira_ical_sync` (horaire) — tire les flux iCal entrants.
* `nira_daily_cleanup` (quotidien) — libère les réservations non payées
  expirées (délai configurable dans les réglages).

== Sécurité ==

* Nonces (`nira_booking`) sur tous les endpoints AJAX publics.
* `check_admin_referer` sur toutes les actions admin.
* Secrets Stripe masqués à la saisie (`••••••••` conserve la valeur existante).
* Webhook Stripe signé (vérif via `whsec_…`).

== Changelog ==

= 2.1.5 =
* Box sur copeaux au mois : tarif corrigé à 680 €.
* Accès au paddock et aux installations indiqué comme compris dans les pensions à la semaine et à la journée.
* Pension au pré : mention « Pendant la belle saison uniquement » et lien de contact pour plus d’informations.

= 2.1.4 =
* Page « Pension & Tarifs » : ajout de la pension au pré (100 % pré) — 250 € / mois sans grain, 300 € / mois avec grain, 150 € / semaine, 20 € / nuit + 5 € / jour / cheval pour le foin.

= 2.1.3 =
* Le script du widget est renommé (`assets/js/booking.js`) : certains caches et plugins de minification servent un fichier indexé sur son chemin en ignorant le numéro de version, ce qui faisait tourner l'ancien script avec le nouveau PHP. Une URL inédite ne peut pas être en cache.
* Le message de confirmation « Demande envoyée » s'affiche sur fond vert.

= 2.1.2 =
* Tolérance au JS périmé : si un cache (navigateur, CDN, plugin de minification) sert encore l'ancien script, la demande de réservation est malgré tout enregistrée et l'écurie prévenue, avec un message de confirmation au visiteur au lieu d'une erreur. Plus aucune demande perdue à cause d'un cache.
* Une demande identique (même hébergement, même e-mail, mêmes dates) de moins d'une heure n'est plus dupliquée : un double clic ou un renvoi n'envoie plus deux e-mails à l'écurie.

= 2.1.1 =
* Les CSS et JS du plugin sont désormais versionnés avec la date de modification du fichier : un JS périmé servi par le cache du navigateur ou de l'hébergeur ne peut plus cohabiter avec un PHP à jour (symptôme : « Stripe n'est pas configuré » au moment d'envoyer une demande).
* En mode demande, l'endpoint de paiement direct refuse explicitement les appels d'un JS périmé au lieu de créer un panier de paiement fantôme qui bloquait les dates pour rien.

= 2.1.0 =
* Nouveau mode « demande de réservation » (activé par défaut, Réglages → Prise de réservation) : le client choisit ses dates et envoie une demande sans payer ; l'écurie reçoit un e-mail avec les boutons Accepter / Refuser ; le lien de paiement n'est envoyé au client qu'après acceptation.
* Les dates ne sont bloquées qu'à partir de l'acceptation, puis réservées pendant un délai configurable (48 h par défaut) le temps que le client règle. Sans paiement dans ce délai, elles sont automatiquement remises en ligne.
* La demande acceptée est réglée en une fois (montant total du séjour), sans acompte.
* Les liens Accepter / Refuser demandent une confirmation sur une page dédiée : un antivirus de messagerie qui précharge le lien ne peut pas valider une demande à l'insu de l'écurie. Motif de refus optionnel, transmis au client.
* Demandes également traitables depuis l'admin (fiche réservation), avec un bandeau « X demandes attendent votre réponse » sur toutes les pages du plugin.
* Nouveaux statuts « Demande à traiter » et « Acceptée — à payer », e-mails dédiés (accusé de réception, acceptation avec lien de paiement, refus).
* Tarifs pension mis à jour : 45 €/jour et 55 €/jour (paille/copeaux), 245 €/sem. et 300 €/sem., 610 €/mois et 635 €/mois, avec la mention de l'accès au paddock et aux installations.

= 2.0.47 =
* Annuler une réservation déjà remboursée depuis le dashboard Stripe fonctionne : le plugin prend acte du remboursement existant (« charge already refunded ») et termine l'annulation en libérant les dates, au lieu d'afficher une erreur et de laisser la réservation confirmée.

= 2.0.46 =
* Liste des réservations épurée : les holds « en attente » (paniers en cours de paiement, expiration automatique) sont masqués par défaut du tableau et du tableau de bord ; ils restent accessibles via le filtre de statut.

= 2.0.45 =
* Un remboursement effectué depuis le dashboard Stripe (webhook `charge.refunded`) est désormais répercuté sur la réservation : montant remboursé enregistré et, si le remboursement est total, réservation passée en « remboursée » avec libération des dates. Avant, ce webhook ne faisait rien et les dates restaient bloquées.

= 2.0.44 =
* Les liens des emails (« Payer le solde », « Annuler ma réservation ») passent désormais par admin-ajax.php au lieu de la page d'accueil : les caches de page complets (IONOS, CDN) servaient l'accueil en cache et ignoraient le lien, qui renvoyait vers le site au lieu de la page de paiement. Les anciens liens restent fonctionnels.

= 2.0.43 =
* Email admin dédié à chaque réservation payée : coordonnées du client, dates, montant payé, solde restant, message du client et lien direct vers la réservation dans l'admin — au lieu d'une copie de l'email client (qui contenait ses liens d'annulation et de paiement du solde).

= 2.0.42 =
* Mode test dans Réglages : passe un hébergement à 1 €/nuit (ménage 0 €, paiement intégral, 1 nuit min) en sauvegardant les vrais prix (prix de base, acompte, remises, règles tarifaires) pour restauration automatique en un clic. Bannière d'avertissement dans tout l'admin tant que le mode est actif.

= 2.0.41 =
* Fiabilité paiement : confirmation de la réservation directement après le paiement (endpoint `nira_confirm_payment` qui revérifie le PaymentIntent auprès de Stripe) — le webhook n'est plus un point de défaillance unique.
* Correctif critique : les holds expirés ou remplacés sont annulés au lieu d'être supprimés — un paiement arrivé en retard retrouve sa réservation (fini les réservations payées qui disparaissent de l'admin).
* Sécurité : signature du webhook Stripe désormais obligatoire (rejet si secret absent ou en-tête manquant), tolérance anti-rejeu de 5 minutes, traitement idempotent des webhooks livrés en double.
* Affichage prix : le récapitulatif du paiement affichait « NaN » et omettait les frais de ménage ; détail désormais complet (nuits, remise, ménage, taxe de séjour, TVA) et cohérent avec le total.
* iCal : chaque flux ne supprime plus que ses propres imports (fini l'effacement croisé entre Airbnb et Booking), fetch sécurisé anti-SSRF, plus de référence interne exposée dans l'export public.
* Divers : anti-abus sur la création de hold (5/15 min par IP), correction du fuseau horaire d'expiration des holds, validation des statuts/dates/chevauchements à la modification d'une réservation dans l'admin.

= 2.0.0 =
* Refonte complète : admin server-rendered, widget frontend façon Airbnb,
  Stripe intégré, iCal bidirectionnel, tout paramétrable depuis WP-Admin.

= 1.0.0 =
* Version initiale.
